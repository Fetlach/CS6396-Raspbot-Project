

from McLumk_Wheel_Sports import *
from Utils import current_milli_time, _angle_deg_from_errx
import RotatoSettings
import RobotState
import time

from Task import task
import config


class greenTask(task):
    def __init__(self, name = "Suraj", quantTime = RotatoSettings.roundRobinQuant):
        super().__init__(name, 0, quantTime)
        self.ReachedTarget = False
    
    def GreenAction(self, green_delta_value):
        speed = 100
        angle_deg = _angle_deg_from_errx(green_delta_value)
        duration = abs(angle_deg / config.SPIN_DEG_PER_SEC) / 2
        
        print(f"Duration is {duration}")
        print(f"GREEN DELTA VALUE IS {green_delta_value}")
        
        if green_delta_value < 0:
            rotate_left(speed)
            
        else:
            rotate_right(speed)
        
        endTime = current_milli_time() + duration
        curTime = current_milli_time()
        
        # KEEP SPINNING for as long as it takes for the bot to turn and face the centroid
        while curTime < endTime:
          curTime = current_milli_time()
          pass
          
        stop_robot()
        

    def setup(self, centroid)->bool:
        return self.GreenAction(centroid)
        

    def start(self) -> bool:
        self.setTimes(current_milli_time(), RotatoSettings.roundRobinQuant)

        completed = False
        
        if not RobotState.state.blueTaskActive:
            completed = self.update()
        
        time.sleep(max(self.endTime - current_milli_time(), 0))
        return completed
        
    def update(self) -> bool:
        while(current_milli_time() < self.endTime):
            self.GreenAction()
        return self.ReachedTarget
    
    def reset(self):
        RobotState.state.greenTaskActive = False
