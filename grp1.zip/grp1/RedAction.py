

from McLumk_Wheel_Sports import *
from Utils import current_milli_time, _angle_deg_from_errx
import RotatoSettings
import RobotState
import time

from Task import task
import config


class redTask(task):
    def __init__(self, name = "Suraj", quantTime = RotatoSettings.roundRobinQuant):
        super().__init__(name, 0, quantTime)

    def RedAction(self):
        
        rotate_left(RotatoSettings.rot180Degree_speed)
        endTime = current_milli_time() + RotatoSettings.rot180Degree_time 
        curTime = current_milli_time()
        
        # KEEP SPINNING for as long as it takes for the bot to turn 180
        while curTime < endTime:
          curTime = current_milli_time()
          pass
                
        stop_robot()
        
    def setup(self, centroid)->bool:
        pass
    
    def update(self) -> bool:
        pass
    
    def reset(self):
        pass
